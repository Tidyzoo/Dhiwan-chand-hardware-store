import { LayoutGrid, PackageCheck, MapPin, MessageCircle } from "lucide-react";
import Reveal from "./Reveal";
import { useEnquiry } from "./Enquiry";

const REASONS = [
  {
    icon: LayoutGrid,
    title: "Wide Everyday Selection",
    desc: "A convenient place to explore household and hardware essentials in one visit.",
  },
  {
    icon: PackageCheck,
    title: "Practical Products",
    desc: "Products selected for everyday household use and common repair needs.",
  },
  {
    icon: MapPin,
    title: "Local Convenience",
    desc: "Right here in Nissing — serving customers across the town and nearby areas.",
  },
  {
    icon: MessageCircle,
    title: "Easy Enquiries",
    desc: "Ask about any product, its availability and current price before you visit.",
  },
];

export default function WhyUs() {
  const enquire = useEnquiry();
  return (
    <section id="why-us" className="scroll-mt-24 bg-pine-deep py-20 text-cream md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <p className="inline-flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass-soft uppercase">
              <span className="h-px w-8 bg-brass-soft" aria-hidden />
              The Store Difference
              <span className="h-px w-8 bg-brass-soft" aria-hidden />
            </p>
            <h2 className="text-balance mt-4 font-display text-3xl font-semibold tracking-tight md:text-5xl">
              Why Customers Choose{" "}
              <em className="text-brass-soft italic">Diwan Chand</em> Bartan &amp; Hardware
            </h2>
          </div>
        </Reveal>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 md:gap-5">
          {REASONS.map((r, i) => (
            <Reveal key={r.title} delay={i * 90}>
              <article className="group flex h-full flex-col rounded-3xl border border-cream/10 bg-cream/[0.04] p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-brass-soft/40 hover:bg-cream/[0.07]">
                <span className="flex items-center justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brass-soft/15 text-brass-soft transition-transform duration-500 group-hover:scale-110">
                    <r.icon className="h-5.5 w-5.5" aria-hidden />
                  </span>
                  <span className="font-display text-sm font-medium text-cream/30">
                    0{i + 1}
                  </span>
                </span>
                <h3 className="mt-6 font-display text-lg font-semibold text-cream">{r.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-cream/65">{r.desc}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <div className="mt-12 flex flex-col items-center justify-between gap-5 rounded-3xl border border-cream/10 bg-cream/[0.04] px-7 py-6 text-center sm:flex-row sm:text-left">
            <p className="text-sm leading-relaxed text-cream/75">
              <span className="font-display text-base font-semibold text-cream">
                One trip. Everything sorted.
              </span>
              <br className="sm:hidden" />
              <span className="sm:ml-2">
                Kitchen refills, repair parts and home essentials — check what you need first.
              </span>
            </p>
            <button
              onClick={() => enquire()}
              className="inline-flex shrink-0 items-center gap-2 rounded-full bg-brass-soft px-6 py-3.5 text-sm font-extrabold text-pine-deep transition-all hover:-translate-y-0.5 hover:shadow-[0_14px_30px_-10px_rgba(201,169,106,0.5)]"
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              Ask About a Product
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
