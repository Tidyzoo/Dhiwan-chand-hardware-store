import {
  MapPin,
  Phone,
  MessageCircle,
  Clock,
  Navigation,
  Search,
  ArrowRight,
} from "lucide-react";
import { STORE, DIRECTIONS_URL, TEL_URL, phoneConfigured } from "../config";
import { useEnquiry } from "./Enquiry";
import Reveal from "./Reveal";

export default function Contact() {
  const enquire = useEnquiry();

  return (
    <>
      {/* Special request banner */}
      <section className="py-20 md:pb-10 md:pt-4" aria-labelledby="specific-heading">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <Reveal>
            <div className="relative overflow-hidden rounded-[2.5rem] bg-pine px-7 py-14 text-center shadow-[var(--shadow-deep)] md:px-16 md:py-20">
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    "radial-gradient(700px 320px at 15% 0%, rgba(201,169,106,0.16), transparent 60%), radial-gradient(600px 300px at 90% 100%, rgba(28,71,55,0.8), transparent 65%)",
                }}
              />
              <div className="relative mx-auto max-w-2xl">
                <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-brass-soft/15 text-brass-soft">
                  <Search className="h-6 w-6" aria-hidden />
                </span>
                <h2
                  id="specific-heading"
                  className="text-balance mt-6 font-display text-3xl font-semibold tracking-tight text-cream md:text-5xl"
                >
                  Looking for Something <em className="text-brass-soft italic">Specific?</em>
                </h2>
                <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-cream/70 md:text-base">
                  Can&apos;t find what you&apos;re looking for? Contact the store and ask about
                  the product you need — the shelves carry far more than this catalogue shows.
                </p>
                <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                  <button
                    onClick={() => enquire()}
                    className="inline-flex items-center gap-2.5 rounded-full bg-brass-soft px-7 py-4 text-sm font-extrabold text-pine-deep transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_16px_36px_-12px_rgba(201,169,106,0.55)]"
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden />
                    Ask on WhatsApp
                  </button>
                  {phoneConfigured && (
                    <a
                      href={TEL_URL}
                      className="inline-flex items-center gap-2.5 rounded-full border border-cream/25 px-7 py-4 text-sm font-bold text-cream transition-all duration-300 hover:-translate-y-0.5 hover:bg-cream/10"
                    >
                      <Phone className="h-4 w-4" aria-hidden />
                      Call the Store
                    </a>
                  )}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Contact / final CTA */}
      <section id="contact" className="scroll-mt-24 py-20 md:py-28" aria-labelledby="contact-heading">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
            <Reveal>
              <p className="flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
                <span className="h-px w-8 bg-brass" aria-hidden />
                Get In Touch
              </p>
              <h2
                id="contact-heading"
                className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-[3.4rem] md:leading-[1.08]"
              >
                Need a Product? Visit or <em className="text-pine italic">Contact Us.</em>
              </h2>
              <p className="mt-5 max-w-lg text-base leading-relaxed text-smoke">
                Check availability before you step out. Send a quick enquiry, or drop by the
                store — we&apos;re easy to find in Nissing.
              </p>

              <div className="mt-9 flex flex-wrap gap-4">
                <a
                  href={DIRECTIONS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 rounded-full bg-pine px-7 py-4 text-sm font-bold text-cream transition-all duration-300 hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-lg"
                >
                  <Navigation className="h-4 w-4" aria-hidden />
                  Get Directions
                </a>
                <button
                  onClick={() => enquire()}
                  className="group inline-flex items-center gap-2.5 rounded-full border border-ink/15 bg-cream px-7 py-4 text-sm font-bold text-ink transition-all duration-300 hover:-translate-y-0.5 hover:border-pine hover:text-pine hover:shadow-lg"
                >
                  <MessageCircle className="h-4 w-4 text-brass transition-colors group-hover:text-pine" aria-hidden />
                  WhatsApp Us
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </button>
              </div>
              {phoneConfigured && (
                <a
                  href={TEL_URL}
                  className="mt-4 inline-flex items-center gap-2.5 rounded-full border border-ink/15 bg-cream px-7 py-4 text-sm font-bold text-ink transition-all hover:border-pine hover:text-pine"
                >
                  <Phone className="h-4 w-4 text-brass" aria-hidden />
                  Call Now
                </a>
              )}
            </Reveal>

            <Reveal delay={140}>
              <dl className="space-y-4 rounded-[2rem] border border-line bg-cream p-7 shadow-[var(--shadow-card)] md:p-9">
                <div className="border-b border-line pb-5">
                  <dt className="text-[10px] font-extrabold tracking-[0.2em] text-brass uppercase">
                    Store
                  </dt>
                  <dd className="mt-1.5 font-display text-lg font-semibold text-ink">
                    {STORE.name}
                  </dd>
                </div>
                <ContactRow
                  icon={MapPin}
                  label="Address"
                  value={STORE.address}
                  placeholder={false}
                />
                <ContactRow
                  icon={Phone}
                  label="Phone"
                  value={STORE.phoneDisplay}
                  placeholder={!phoneConfigured}
                />
                <ContactRow
                  icon={MessageCircle}
                  label="WhatsApp"
                  value={STORE.whatsappDisplay}
                  placeholder
                />
                <ContactRow
                  icon={Clock}
                  label="Opening Hours"
                  value={STORE.hoursDisplay}
                  placeholder
                  last
                />
              </dl>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}

function ContactRow({
  icon: Icon,
  label,
  value,
  placeholder,
  last,
}: {
  icon: typeof MapPin;
  label: string;
  value: string;
  placeholder: boolean;
  last?: boolean;
}) {
  return (
    <div className={`flex items-start gap-4 ${last ? "" : "border-b border-line pb-5"}`}>
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sand text-pine">
        <Icon className="h-4.5 w-4.5" aria-hidden />
      </span>
      <div>
        <dt className="text-[10px] font-extrabold tracking-[0.2em] text-smoke uppercase">{label}</dt>
        <dd
          className={`mt-1 text-sm leading-relaxed font-semibold ${
            placeholder ? "font-mono text-brass" : "text-ink"
          }`}
        >
          {value}
        </dd>
      </div>
    </div>
  );
}
