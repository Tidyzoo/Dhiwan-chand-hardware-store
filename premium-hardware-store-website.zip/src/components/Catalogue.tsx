import { useMemo, useState } from "react";
import { Search, MessageCircle, PackageSearch, Sparkles, Plus } from "lucide-react";
import { PRODUCTS, CATEGORY_LABELS, type CategoryId, type Product } from "../data/products";
import { useEnquiry } from "./Enquiry";
import Reveal from "./Reveal";

type FilterId = "all" | CategoryId | "new";

const FILTERS: { id: FilterId; label: string }[] = [
  { id: "all", label: "All" },
  { id: "bartan", label: "Bartan & Kitchen" },
  { id: "hardware", label: "Hardware" },
  { id: "home", label: "Home Essentials" },
  { id: "tools", label: "Tools" },
  { id: "new", label: "New Arrivals" },
];

export default function Catalogue() {
  const [filter, setFilter] = useState<FilterId>("all");
  const [query, setQuery] = useState("");
  const enquire = useEnquiry();

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PRODUCTS.filter((p) => {
      const inFilter =
        filter === "all" ? true : filter === "new" ? Boolean(p.isNew) : p.category === filter;
      if (!inFilter) return false;
      if (!q) return true;
      const haystack = `${p.name} ${p.desc} ${CATEGORY_LABELS[p.category]} ${p.keywords.join(
        " ",
      )}`.toLowerCase();
      return q.split(/\s+/).every((word) => haystack.includes(word));
    });
  }, [filter, query]);

  return (
    <section id="products" className="scroll-mt-24 bg-cream py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="text-center">
            <p className="inline-flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
              <span className="h-px w-8 bg-brass" aria-hidden />
              Product Catalogue
              <span className="h-px w-8 bg-brass" aria-hidden />
            </p>
            <h2 className="text-balance mx-auto mt-4 max-w-2xl font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl">
              Browse Our <em className="text-pine italic">Products</em>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-smoke md:text-base">
              Search the range, see something useful, and ask the store about availability and
              the current price — no guesswork needed.
            </p>
          </div>
        </Reveal>

        {/* Search + filters */}
        <Reveal delay={120}>
          <div className="sticky top-[4.25rem] z-30 mt-10 rounded-3xl border border-line bg-ivory/95 p-3 shadow-[var(--shadow-card)] backdrop-blur-xl md:top-24">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
              <label className="relative flex-1" htmlFor="product-search">
                <Search
                  className="pointer-events-none absolute top-1/2 left-4 h-4.5 w-4.5 -translate-y-1/2 text-smoke"
                  aria-hidden
                />
                <input
                  id="product-search"
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="What are you looking for? Try “pressure cooker”, “steel utensils”, “tools”…"
                  className="w-full rounded-full border border-line bg-white py-3.5 pr-4 pl-12 text-sm font-semibold text-ink placeholder:font-medium placeholder:text-smoke/70 focus:border-brass"
                />
              </label>
              <div
                className="scrollbar-hide flex gap-2 overflow-x-auto pb-1 lg:pb-0"
                role="tablist"
                aria-label="Filter products"
              >
                {FILTERS.map((f) => (
                  <button
                    key={f.id}
                    role="tab"
                    aria-selected={filter === f.id}
                    onClick={() => setFilter(f.id)}
                    className={`shrink-0 rounded-full px-4.5 py-2.5 text-xs font-bold whitespace-nowrap transition-all duration-300 ${
                      filter === f.id
                        ? "bg-pine text-cream shadow-md"
                        : "border border-line bg-white text-smoke hover:border-pine/40 hover:text-pine"
                    }`}
                  >
                    {f.id === "new" && (
                      <Sparkles className="mr-1.5 -ml-0.5 inline h-3.5 w-3.5 align-[-2px]" aria-hidden />
                    )}
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        {/* Result meta */}
        <div className="mt-8 flex items-center justify-between gap-4">
          <p className="text-xs font-bold tracking-wider text-smoke uppercase" aria-live="polite">
            {results.length} {results.length === 1 ? "product" : "products"}
            {filter !== "all" && ` · ${FILTERS.find((f) => f.id === filter)?.label}`}
            {query && ` · “${query}”`}
          </p>
          <p className="hidden text-xs font-semibold text-brass sm:block">Catalogue growing weekly</p>
        </div>

        {/* Grid */}
        {results.length > 0 ? (
          <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-5 xl:grid-cols-4">
            {results.map((p, i) => (
              <Reveal key={p.id} delay={Math.min(i, 7) * 60}>
                <ProductCard product={p} onEnquire={() => enquire({ product: p })} />
              </Reveal>
            ))}
            {/* Expandable catalogue placeholder card */}
            {filter === "all" && !query && (
              <Reveal delay={420}>
                <button
                  onClick={() => enquire()}
                  className="group flex h-full min-h-[320px] w-full flex-col items-center justify-center gap-4 rounded-2xl border-2 border-dashed border-line bg-ivory/50 p-6 text-center transition-all duration-300 hover:border-brass/60 hover:bg-ivory"
                >
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-cream text-smoke transition-all duration-300 group-hover:scale-110 group-hover:border-brass group-hover:text-brass">
                    <Plus className="h-5 w-5" aria-hidden />
                  </span>
                  <span className="font-display text-lg font-semibold text-ink">
                    More in store
                  </span>
                  <span className="max-w-[220px] text-xs leading-relaxed text-smoke">
                    This catalogue is expandable — the full in-store range is much wider. Ask
                    about anything you need.
                  </span>
                </button>
              </Reveal>
            )}
          </div>
        ) : (
          <div className="mt-6 flex flex-col items-center gap-5 rounded-3xl border border-dashed border-line bg-ivory/60 px-6 py-16 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-sand text-pine">
              <PackageSearch className="h-6 w-6" aria-hidden />
            </span>
            <div>
              <p className="font-display text-xl font-semibold text-ink">
                Not listed — but we may still have it
              </p>
              <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-smoke">
                The online catalogue shows sample products only. The store shelves carry much
                more, so send a quick enquiry and check.
              </p>
            </div>
            <button
              onClick={() => enquire()}
              className="inline-flex items-center gap-2 rounded-full bg-pine px-6 py-3.5 text-sm font-bold text-cream transition-all hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-lg"
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              Ask About This Product
            </button>
          </div>
        )}

        <Reveal delay={150}>
          <p className="mt-10 text-center text-xs leading-relaxed text-smoke">
            Sample products shown for browsing —{" "}
            <span className="font-semibold text-ink">price &amp; availability on request</span>.
            The owner can add the real inventory to this catalogue anytime.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

function ProductCard({ product: p, onEnquire }: { product: Product; onEnquire: () => void }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-[var(--shadow-card)] transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[var(--shadow-lift)]">
      <div className="img-fade relative m-2 overflow-hidden rounded-xl md:m-2.5">
        <img
          src={p.image}
          alt={p.imageAlt}
          loading="lazy"
          className="aspect-[4/3] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.08]"
        />
        {p.isNew && (
          <span className="absolute top-2.5 left-2.5 rounded-full bg-brass px-2.5 py-1 text-[9px] font-extrabold tracking-[0.14em] text-cream uppercase shadow-md">
            New Arrival
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col px-4 pb-4 md:px-5 md:pb-5">
        <p className="text-[10px] font-extrabold tracking-[0.16em] text-brass uppercase">
          {CATEGORY_LABELS[p.category]}
        </p>
        <h3 className="mt-1.5 font-display text-[15px] leading-snug font-semibold text-ink md:text-[17px]">
          {p.name}
        </h3>
        <p className="mt-1.5 line-clamp-2 hidden text-xs leading-relaxed text-smoke sm:block">
          {p.desc}
        </p>
        <div className="mt-4 flex items-center justify-between gap-2 border-t border-line pt-3.5">
          <span className="text-[11px] font-extrabold tracking-wide text-pine uppercase">
            Price on request
          </span>
          <button
            onClick={onEnquire}
            aria-label={`Ask about ${p.name}`}
            className="inline-flex items-center gap-1.5 rounded-full bg-pine px-3.5 py-2 text-[11px] font-bold text-cream transition-all duration-300 hover:bg-pine-soft hover:shadow-md active:scale-95 md:px-4"
          >
            <MessageCircle className="h-3.5 w-3.5" aria-hidden />
            Enquire
          </button>
        </div>
      </div>
    </article>
  );
}
