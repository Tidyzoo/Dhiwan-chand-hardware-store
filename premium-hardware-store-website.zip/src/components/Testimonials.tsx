import { Quote, BadgeCheck } from "lucide-react";
import Reveal from "./Reveal";

/**
 * REVIEWS PLACEHOLDER
 * -------------------
 * Genuine customer reviews only. These placeholder cards are shown
 * during setup and must be replaced with real feedback supplied by
 * the store owner (or sourced from a public business profile).
 */
const PLACEHOLDERS = [0, 1, 2];

export default function Testimonials() {
  return (
    <section className="bg-cream py-20 md:py-28" aria-labelledby="reviews-heading">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="inline-flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
              <span className="h-px w-8 bg-brass" aria-hidden />
              Customer Voices
              <span className="h-px w-8 bg-brass" aria-hidden />
            </p>
            <h2
              id="reviews-heading"
              className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl"
            >
              What Our <em className="text-pine italic">Customers Say</em>
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-smoke">
              Genuine feedback from the people we serve will appear here. No review is published
              until it comes from a real customer.
            </p>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-4 md:grid-cols-3 md:gap-5">
          {PLACEHOLDERS.map((i) => (
            <Reveal key={i} delay={i * 90}>
              <figure className="flex h-full flex-col rounded-3xl border-2 border-dashed border-line bg-ivory/60 p-7">
                <div className="flex items-center justify-between">
                  <Quote className="h-6 w-6 text-brass/50" aria-hidden />
                  <span className="rounded-full border border-dashed border-brass/50 bg-brass/5 px-3 py-1 text-[9px] font-extrabold tracking-[0.16em] text-brass uppercase">
                    Placeholder
                  </span>
                </div>
                <blockquote className="mt-5 flex-1 font-display text-[15px] leading-relaxed text-ink/60 italic">
                  “This space is reserved for genuine customer feedback, shared directly with the
                  store or collected from its public business profile.”
                </blockquote>
                <figcaption className="mt-6 border-t border-dashed border-line pt-4">
                  <p className="text-xs font-extrabold text-smoke">Customer name &amp; review</p>
                  <p className="text-[11px] text-smoke/70">To be added by the store owner</p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal delay={160}>
          <p className="mt-8 flex flex-wrap items-center justify-center gap-2 text-center text-xs text-smoke">
            <BadgeCheck className="h-4 w-4 text-pine" aria-hidden />
            Visited the store? Share your honest experience with the owner to be featured here.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
