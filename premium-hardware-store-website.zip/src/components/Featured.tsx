import { useRef } from "react";
import { ArrowLeft, ArrowRight, MessageCircle } from "lucide-react";
import { FEATURED_PRODUCTS, CATEGORY_LABELS } from "../data/products";
import { useEnquiry } from "./Enquiry";
import Reveal from "./Reveal";

export default function Featured() {
  const trackRef = useRef<HTMLDivElement>(null);
  const enquire = useEnquiry();

  const scrollBy = (dir: 1 | -1) => {
    const el = trackRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * Math.min(el.clientWidth * 0.8, 560), behavior: "smooth" });
  };

  return (
    <section className="overflow-hidden py-20 md:py-28" aria-labelledby="featured-heading">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-2xl">
              <p className="flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
                <span className="h-px w-8 bg-brass" aria-hidden />
                Popular Store Essentials
              </p>
              <h2
                id="featured-heading"
                className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl"
              >
                Favourites For <em className="text-pine italic">Every Home</em>
              </h2>
            </div>
            <div className="flex gap-2.5">
              <button
                onClick={() => scrollBy(-1)}
                aria-label="Scroll featured products left"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-line bg-cream text-ink transition-all hover:border-pine hover:bg-pine hover:text-cream"
              >
                <ArrowLeft className="h-4.5 w-4.5" aria-hidden />
              </button>
              <button
                onClick={() => scrollBy(1)}
                aria-label="Scroll featured products right"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-line bg-cream text-ink transition-all hover:border-pine hover:bg-pine hover:text-cream"
              >
                <ArrowRight className="h-4.5 w-4.5" aria-hidden />
              </button>
            </div>
          </div>
        </Reveal>
      </div>

      <Reveal delay={140}>
        <div
          ref={trackRef}
          className="scrollbar-hide mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth px-5 pb-4 md:gap-5 md:px-[max(2rem,calc((100vw-80rem)/2+2rem))]"
        >
          {FEATURED_PRODUCTS.map((p) => (
            <article
              key={p.id}
              className="group relative w-[240px] shrink-0 snap-start overflow-hidden rounded-3xl border border-line bg-white shadow-[var(--shadow-card)] transition-all duration-500 hover:-translate-y-2 hover:shadow-[var(--shadow-lift)] sm:w-[280px]"
            >
              <div className="img-fade relative m-2 overflow-hidden rounded-2xl">
                <img
                  src={p.image}
                  alt={p.imageAlt}
                  loading="lazy"
                  className="aspect-square w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.07]"
                />
                <span className="absolute top-3 left-3 rounded-full bg-pine-deep/70 px-3 py-1 text-[9px] font-extrabold tracking-[0.16em] text-brass-soft uppercase backdrop-blur-sm">
                  {CATEGORY_LABELS[p.category]}
                </span>
              </div>
              <div className="px-5 pb-5">
                <h3 className="font-display text-[16px] leading-snug font-semibold text-ink">
                  {p.name}
                </h3>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <span className="text-[11px] font-extrabold tracking-wide text-pine uppercase">
                    Ask for price
                  </span>
                  <button
                    onClick={() => enquire({ product: p })}
                    aria-label={`Ask about ${p.name}`}
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-pine transition-all duration-300 group-hover:border-pine group-hover:bg-pine group-hover:text-cream"
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden />
                  </button>
                </div>
              </div>
            </article>
          ))}

          {/* CTA end card */}
          <div className="flex w-[240px] shrink-0 snap-start flex-col items-center justify-center gap-4 rounded-3xl bg-pine-deep p-7 text-center sm:w-[280px]">
            <p className="font-display text-xl leading-snug font-semibold text-cream">
              Much more on the shelves
            </p>
            <p className="text-xs leading-relaxed text-cream/70">
              These are sample placeholders until the real inventory is photographed and added.
            </p>
            <a
              href="#products"
              className="inline-flex items-center gap-2 rounded-full bg-brass-soft px-5 py-3 text-xs font-extrabold text-pine-deep transition-transform hover:scale-105"
            >
              Browse the catalogue
              <ArrowRight className="h-3.5 w-3.5" aria-hidden />
            </a>
          </div>
        </div>
      </Reveal>

      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <p className="mt-4 text-xs text-smoke">
          Sample products shown — brands, prices and stock are confirmed directly with the store.
        </p>
      </div>
    </section>
  );
}
