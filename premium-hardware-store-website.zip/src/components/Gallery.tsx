import { Camera } from "lucide-react";
import Reveal from "./Reveal";

const IMAGES = [
  {
    src: "/images/store-exterior.jpg",
    alt: "Store exterior in the evening with steel bartan on display",
    caption: "The storefront",
    ratio: "aspect-[4/5]",
  },
  {
    src: "https://images.pexels.com/photos/35285900/pexels-photo-35285900.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Kitchenware displayed on rustic store shelves",
    caption: "Kitchen & bartan shelves",
    ratio: "aspect-[4/3]",
  },
  {
    src: "/images/store-interior.jpg",
    alt: "Store interior with shelves of bartan and household products",
    caption: "Inside the shop",
    ratio: "aspect-[4/3]",
  },
  {
    src: "https://images.pexels.com/photos/28700640/pexels-photo-28700640.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Close-up of assorted metal screws and bolts",
    caption: "Hardware, up close",
    ratio: "aspect-[3/4]",
  },
  {
    src: "https://images.pexels.com/photos/7705368/pexels-photo-7705368.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Store shelf with bowls, bottles and kitchen items",
    caption: "Shelves & storage",
    ratio: "aspect-[3/4]",
  },
  {
    src: "https://images.pexels.com/photos/18071812/pexels-photo-18071812.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    alt: "Stainless steel pots on a cooktop",
    caption: "Everyday cookware",
    ratio: "aspect-[4/3]",
  },
];

export default function Gallery() {
  return (
    <section id="gallery" className="scroll-mt-24 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-2xl">
              <p className="flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
                <span className="h-px w-8 bg-brass" aria-hidden />
                Photo Gallery
              </p>
              <h2 className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl">
                Inside Our <em className="text-pine italic">Store</em>
              </h2>
            </div>
            <p className="flex max-w-sm items-start gap-2.5 text-sm leading-relaxed text-smoke">
              <Camera className="mt-0.5 h-4 w-4 shrink-0 text-brass" aria-hidden />
              Placeholder photography for now — these frames are ready to be replaced with real
              photographs from the shop floor.
            </p>
          </div>
        </Reveal>

        <div className="masonry mt-12 columns-2 lg:columns-3">
          {IMAGES.map((img, i) => (
            <Reveal key={img.src} delay={(i % 3) * 80} className="mb-4">
              <figure className="group relative overflow-hidden rounded-2xl border border-line shadow-[var(--shadow-card)]">
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className={`${img.ratio} w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]`}
                />
                <figcaption className="absolute inset-x-3 bottom-3 translate-y-2 rounded-xl bg-pine-deep/70 px-4 py-2.5 text-[11px] font-bold tracking-wide text-cream opacity-0 backdrop-blur-md transition-all duration-400 group-hover:translate-y-0 group-hover:opacity-100">
                  {img.caption}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
