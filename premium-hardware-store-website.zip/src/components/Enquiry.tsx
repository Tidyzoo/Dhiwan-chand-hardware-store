import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import {
  X,
  MessageCircle,
  Copy,
  Check,
  Phone,
  Navigation,
  ClipboardList,
} from "lucide-react";
import type { Product } from "../data/products";
import {
  STORE,
  GENERAL_MESSAGE,
  productMessage,
  whatsappUrl,
  whatsappConfigured,
  phoneConfigured,
  TEL_URL,
  DIRECTIONS_URL,
} from "../config";

export interface EnquiryTarget {
  product?: Product;
}

type OpenEnquiry = (target?: EnquiryTarget) => void;

const EnquiryContext = createContext<OpenEnquiry>(() => {});

export const useEnquiry = () => useContext(EnquiryContext);

export function EnquiryProvider({ children }: { children: ReactNode }) {
  const [target, setTarget] = useState<EnquiryTarget | null>(null);
  const open = useCallback<OpenEnquiry>((t) => setTarget(t ?? {}), []);
  const close = useCallback(() => setTarget(null), []);

  return (
    <EnquiryContext.Provider value={open}>
      {children}
      {target && <EnquiryModal target={target} onClose={close} />}
    </EnquiryContext.Provider>
  );
}

function EnquiryModal({ target, onClose }: { target: EnquiryTarget; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const message = target.product
    ? productMessage(target.product.name)
    : GENERAL_MESSAGE;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.documentElement.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.documentElement.style.overflow = "";
    };
  }, [onClose]);

  const copyMessage = async () => {
    try {
      await navigator.clipboard.writeText(message);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = message;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div
      className="fixed inset-0 z-[90] flex items-end justify-center bg-ink/60 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Product enquiry"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg overflow-hidden rounded-t-3xl bg-cream shadow-[0_40px_100px_-20px_rgba(14,38,29,0.6)] sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-line bg-ivory px-6 py-5">
          <div className="flex items-center gap-4">
            {target.product ? (
              <img
                src={target.product.image}
                alt={target.product.imageAlt}
                className="h-14 w-14 rounded-xl border border-line object-cover"
              />
            ) : (
              <span className="flex h-14 w-14 items-center justify-center rounded-xl border border-line bg-pine text-cream">
                <ClipboardList className="h-6 w-6" aria-hidden />
              </span>
            )}
            <div>
              <p className="text-[11px] font-bold tracking-[0.18em] text-brass uppercase">
                {target.product ? "Product enquiry" : "General enquiry"}
              </p>
              <h3 className="font-display text-lg leading-snug font-semibold text-ink">
                {target.product ? target.product.name : "Ask about any product"}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close enquiry"
            className="rounded-full border border-line bg-cream p-2 text-smoke transition hover:bg-sand hover:text-ink"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
        </div>

        {/* Message preview */}
        <div className="space-y-5 px-6 py-6">
          <div>
            <p className="mb-2 text-xs font-bold tracking-wider text-smoke uppercase">
              Your message — pre-filled
            </p>
            <p className="rounded-2xl border border-line bg-white p-4 text-sm leading-relaxed text-ink">
              “{message}”
            </p>
          </div>

          {/* Actions */}
          <div className="grid gap-3">
            {whatsappConfigured ? (
              <a
                href={whatsappUrl(message)}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-pine px-6 py-4 text-sm font-bold text-cream transition-all hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-lg"
              >
                <MessageCircle className="h-4.5 w-4.5" aria-hidden />
                Ask on WhatsApp
              </a>
            ) : (
              <button
                onClick={copyMessage}
                className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-pine px-6 py-4 text-sm font-bold text-cream transition-all hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-lg"
              >
                <MessageCircle className="h-4.5 w-4.5" aria-hidden />
                Ask on WhatsApp
              </button>
            )}

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={copyMessage}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-ink/15 bg-white px-4 py-3 text-sm font-bold text-ink transition hover:border-pine hover:text-pine"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-pine" aria-hidden />
                ) : (
                  <Copy className="h-4 w-4" aria-hidden />
                )}
                {copied ? "Copied" : "Copy message"}
              </button>
              {phoneConfigured ? (
                <a
                  href={TEL_URL}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-ink/15 bg-white px-4 py-3 text-sm font-bold text-ink transition hover:border-pine hover:text-pine"
                >
                  <Phone className="h-4 w-4" aria-hidden />
                  Call the store
                </a>
              ) : (
                <a
                  href={DIRECTIONS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-ink/15 bg-white px-4 py-3 text-sm font-bold text-ink transition hover:border-pine hover:text-pine"
                >
                  <Navigation className="h-4 w-4" aria-hidden />
                  Get directions
                </a>
              )}
            </div>
          </div>

          {/* Placeholder notice — replaced once the owner adds contact details */}
          {!whatsappConfigured && (
            <p className="rounded-xl border border-dashed border-brass/50 bg-brass/5 px-4 py-3 text-xs leading-relaxed text-smoke">
              <span className="font-bold text-brass">Store setup note:</span> WhatsApp number{" "}
              <span className="font-mono font-semibold text-ink">{STORE.whatsappDisplay}</span> —
              once the owner adds it, this button opens WhatsApp with the message pre-filled. The
              message has been copied to your clipboard.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
