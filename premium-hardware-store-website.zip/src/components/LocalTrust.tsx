import { MapPin, ShieldCheck, Navigation } from "lucide-react";
import { STORE, DIRECTIONS_URL } from "../config";
import Reveal from "./Reveal";

export default function LocalTrust() {
  return (
    <section className="bg-cream py-20 md:py-28" aria-labelledby="local-heading">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <Reveal>
            <p className="flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
              <span className="h-px w-8 bg-brass" aria-hidden />
              Your Neighbourhood Store
            </p>
            <h2
              id="local-heading"
              className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl"
            >
              Serving Nissing &amp; <em className="text-pine italic">Nearby Customers</em>
            </h2>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-smoke">
              A local store for local homes. Whether it&apos;s a new steel dinner set, a
              replacement washer, or a tool for a weekend repair — start here in Nissing
              instead of travelling far.
            </p>

            <ul className="mt-8 space-y-3">
              {[
                { label: "Store", value: STORE.name },
                { label: "Address", value: STORE.address },
                {
                  label: "Area served",
                  value: "Nissing and surrounding areas, Karnal district, Haryana",
                },
              ].map((row) => (
                <li
                  key={row.label}
                  className="flex items-start gap-4 rounded-2xl border border-line bg-ivory px-5 py-4"
                >
                  <ShieldCheck className="mt-0.5 h-4.5 w-4.5 shrink-0 text-pine" aria-hidden />
                  <div>
                    <p className="text-[10px] font-extrabold tracking-[0.2em] text-brass uppercase">
                      {row.label} · verified
                    </p>
                    <p className="mt-1 text-sm font-semibold text-ink">{row.value}</p>
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-xs leading-relaxed text-smoke">
              We publish only information confirmed by the store — no invented prices, reviews
              or claims.
            </p>
          </Reveal>

          <Reveal delay={140}>
            {/* Location graphic card */}
            <div className="relative overflow-hidden rounded-[2rem] bg-pine-deep p-8 shadow-[var(--shadow-deep)] md:p-10">
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0"
                style={{
                  backgroundImage:
                    "radial-gradient(rgba(201,169,106,0.16) 1px, transparent 1px)",
                  backgroundSize: "22px 22px",
                }}
              />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <MapPin className="h-8 w-8 text-brass-soft" aria-hidden />
                  <span className="rounded-full border border-cream/15 px-3.5 py-1.5 text-[10px] font-extrabold tracking-[0.2em] text-cream/70 uppercase">
                    Haryana, India
                  </span>
                </div>
                <p
                  aria-hidden
                  className="mt-8 font-display text-[clamp(4rem,10vw,7.5rem)] leading-none font-bold tracking-tight text-transparent"
                  style={{ WebkitTextStroke: "1.5px rgba(201,169,106,0.55)" }}
                >
                  132024
                </p>
                <p className="mt-3 font-display text-2xl font-semibold text-cream">
                  Nissing, Karnal district
                </p>
                <p className="mt-2 text-sm leading-relaxed text-cream/60">
                  {STORE.name} · {STORE.addressShort}
                </p>
                <a
                  href={DIRECTIONS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-8 inline-flex items-center gap-2 rounded-full bg-brass-soft px-6 py-3.5 text-sm font-extrabold text-pine-deep transition-all hover:-translate-y-0.5 hover:shadow-[0_14px_30px_-10px_rgba(201,169,106,0.5)]"
                >
                  <Navigation className="h-4 w-4" aria-hidden />
                  Open in Google Maps
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
