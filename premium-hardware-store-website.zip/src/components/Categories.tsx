import { ArrowUpRight } from "lucide-react";
import Reveal from "./Reveal";

const CATEGORIES = [
  {
    id: "kitchen-bartan",
    index: "01",
    title: "Kitchen & Bartan",
    blurb: "Stainless steel utensils, cookware and kitchen accessories for daily cooking.",
    items: ["Steel utensils", "Cookware", "Kitchen accessories", "Serving items", "Storage"],
    image: "/images/cat-kitchen.jpg",
    alt: "Stack of polished stainless steel Indian kitchen bartan",
  },
  {
    id: "hardware",
    index: "02",
    title: "Hardware",
    blurb: "General hardware, fasteners and fittings for repairs and small projects.",
    items: ["General hardware", "Fasteners", "Fittings", "Everyday repair items"],
    image: "/images/cat-hardware.jpg",
    alt: "Assorted hardware fittings, screws and brackets on a dark surface",
  },
  {
    id: "home-essentials",
    index: "03",
    title: "Home Essentials",
    blurb: "Household utility products, storage solutions and everyday-use items.",
    items: ["Utility products", "Cleaning items", "Storage solutions", "Daily-use goods"],
    image: "/images/cat-home.jpg",
    alt: "Household essentials including buckets, jugs and storage baskets",
  },
  {
    id: "tools",
    index: "04",
    title: "Tools & Accessories",
    blurb: "Hand tools, repair accessories and workshop essentials for every toolbox.",
    items: ["Hand tools", "Repair accessories", "Workshop essentials"],
    image: "/images/cat-tools.jpg",
    alt: "Hand tools arranged on a deep green backdrop",
  },
];

export default function Categories() {
  return (
    <section id="categories" className="scroll-mt-24 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-2xl">
              <p className="flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
                <span className="h-px w-8 bg-brass" aria-hidden />
                The Catalogue
              </p>
              <h2 className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl">
                Explore Our <em className="text-pine italic">Categories</em>
              </h2>
            </div>
            <p className="max-w-sm text-sm leading-relaxed text-smoke">
              A suggested catalogue of the store&apos;s range. Ask in store for the full,
              up-to-date selection — new stock arrives regularly.
            </p>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {CATEGORIES.map((cat, i) => (
            <Reveal key={cat.id} delay={i * 90}>
              <a
                href={`#products`}
                className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-line bg-cream shadow-[var(--shadow-card)] transition-all duration-500 hover:-translate-y-2 hover:shadow-[var(--shadow-lift)]"
                aria-label={`Browse ${cat.title} products`}
              >
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={cat.image}
                    alt={cat.alt}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                  />
                  <span className="absolute top-4 left-4 rounded-full bg-pine-deep/70 px-3 py-1 font-display text-xs font-semibold text-brass-soft backdrop-blur-sm">
                    {cat.index}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-xl font-semibold text-ink">{cat.title}</h3>
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line text-smoke transition-all duration-300 group-hover:rotate-45 group-hover:border-pine group-hover:bg-pine group-hover:text-cream">
                      <ArrowUpRight className="h-4 w-4" aria-hidden />
                    </span>
                  </div>
                  <p className="mt-2 text-[13px] leading-relaxed text-smoke">{cat.blurb}</p>
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {cat.items.map((item) => (
                      <li
                        key={item}
                        className="rounded-full bg-sand px-2.5 py-1 text-[10px] font-bold tracking-wide text-pine-deep"
                      >
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </a>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mt-8 rounded-2xl border border-dashed border-brass/40 bg-cream px-5 py-4 text-center text-xs leading-relaxed text-smoke">
            <span className="font-bold text-brass">Please note:</span> categories are indicative of
            a typical bartan &amp; hardware range. Exact stock changes — please ask the store
            about any specific item.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
