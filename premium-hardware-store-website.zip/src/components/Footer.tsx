import { MapPin, Phone, MessageCircle, Navigation, ArrowUpRight } from "lucide-react";
import { STORE, DIRECTIONS_URL, MAPS_VIEW_URL, phoneConfigured, TEL_URL } from "../config";
import { useEnquiry } from "./Enquiry";

const NAV = [
  { label: "Home", href: "#home" },
  { label: "Categories", href: "#categories" },
  { label: "Products", href: "#products" },
  { label: "Gallery", href: "#gallery" },
  { label: "About the Store", href: "#visit" },
  { label: "Contact", href: "#contact" },
];

export default function Footer() {
  const enquire = useEnquiry();

  return (
    <footer className="bg-pine-deep text-cream" role="contentinfo">
      <div className="mx-auto max-w-7xl px-5 pt-16 pb-32 md:px-8 md:pt-20 md:pb-12">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_0.7fr_1fr]">
          {/* Brand */}
          <div>
            <p className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
              {STORE.brandLine1}
              <span className="mt-1 block text-sm font-sans font-extrabold tracking-[0.28em] text-brass-soft uppercase">
                Bartan &amp; Hardware Store
              </span>
            </p>
            <p className="mt-4 max-w-sm font-display text-base text-cream/60 italic">
              “{STORE.tagline}”
            </p>
            <address className="mt-6 flex items-start gap-2 text-sm leading-relaxed text-cream/70 not-italic">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brass-soft" aria-hidden />
              {STORE.address}
            </address>
          </div>

          {/* Navigation */}
          <nav aria-label="Footer">
            <p className="text-[10px] font-extrabold tracking-[0.24em] text-brass-soft uppercase">
              Explore
            </p>
            <ul className="mt-5 space-y-3">
              {NAV.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="group inline-flex items-center gap-1.5 text-sm font-semibold text-cream/70 transition-colors hover:text-brass-soft"
                  >
                    {l.label}
                    <ArrowUpRight
                      className="h-3 w-3 opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100"
                      aria-hidden
                    />
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <p className="text-[10px] font-extrabold tracking-[0.24em] text-brass-soft uppercase">
              Contact &amp; Directions
            </p>
            <ul className="mt-5 space-y-4 text-sm">
              <li>
                <a
                  href={MAPS_VIEW_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-3 font-semibold text-cream/70 transition-colors hover:text-cream"
                >
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-cream/15 text-brass-soft transition-colors group-hover:border-brass-soft/50">
                    <Navigation className="h-4 w-4" aria-hidden />
                  </span>
                  Find us on Google Maps
                </a>
              </li>
              <li>
                <button
                  onClick={() => enquire()}
                  className="group flex items-center gap-3 font-semibold text-cream/70 transition-colors hover:text-cream"
                >
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-cream/15 text-brass-soft transition-colors group-hover:border-brass-soft/50">
                    <MessageCircle className="h-4 w-4" aria-hidden />
                  </span>
                  WhatsApp{" "}
                  <span className="font-mono text-xs text-brass-soft/70">
                    {STORE.whatsappDisplay}
                  </span>
                </button>
              </li>
              <li>
                {phoneConfigured ? (
                  <a
                    href={TEL_URL}
                    className="group flex items-center gap-3 font-semibold text-cream/70 transition-colors hover:text-cream"
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-cream/15 text-brass-soft transition-colors group-hover:border-brass-soft/50">
                      <Phone className="h-4 w-4" aria-hidden />
                    </span>
                    Call the store
                  </a>
                ) : (
                  <span className="flex items-center gap-3 font-semibold text-cream/50">
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-cream/10 text-brass-soft/60">
                      <Phone className="h-4 w-4" aria-hidden />
                    </span>
                    Phone <span className="font-mono text-xs">{STORE.phoneDisplay}</span>
                  </span>
                )}
              </li>
            </ul>
            <a
              href={DIRECTIONS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-brass-soft px-5 py-3 text-xs font-extrabold text-pine-deep transition-all hover:-translate-y-0.5 hover:shadow-lg"
            >
              <Navigation className="h-3.5 w-3.5" aria-hidden />
              Get Directions
            </a>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-cream/10 pt-7 text-center sm:flex-row sm:text-left">
          <p className="text-xs text-cream/50">
            © 2026 {STORE.name}. All rights reserved.
          </p>
          <p className="text-[11px] text-cream/40">
            Contact details &amp; reviews shown here will be updated once verified by the store.
          </p>
        </div>
      </div>
    </footer>
  );
}
