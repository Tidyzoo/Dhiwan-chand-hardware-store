import { Home, LayoutGrid, MessageCircle, Navigation } from "lucide-react";
import { DIRECTIONS_URL } from "../config";
import { useEnquiry } from "./Enquiry";

/** Sticky mobile action bar + floating WhatsApp button. */
export default function MobileDock() {
  const enquire = useEnquiry();

  return (
    <>
      {/* Floating WhatsApp — visible on every screen, lifted above the mobile bar */}
      <button
        onClick={() => enquire()}
        aria-label="Ask on WhatsApp"
        className="animate-float fixed right-4 bottom-24 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-pine text-cream shadow-[0_18px_40px_-10px_rgba(20,53,42,0.65)] ring-1 ring-cream/20 transition-transform hover:scale-105 active:scale-95 md:right-6 md:bottom-6"
      >
        <MessageCircle className="h-6 w-6" aria-hidden />
        <span className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-ivory bg-brass" aria-hidden />
      </button>

      {/* Sticky mobile navigation */}
      <nav
        className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-4 gap-1 rounded-2xl border border-line bg-cream/95 p-1.5 shadow-[0_16px_40px_-12px_rgba(27,30,27,0.4)] backdrop-blur-xl md:hidden"
        aria-label="Quick actions"
      >
        <DockLink href="#home" icon={Home} label="Home" />
        <DockLink href="#products" icon={LayoutGrid} label="Products" />
        <DockButton onClick={() => enquire()} icon={MessageCircle} label="WhatsApp" accent />
        <DockLink href={DIRECTIONS_URL} icon={Navigation} label="Directions" external />
      </nav>
    </>
  );
}

function DockLink({
  href,
  icon: Icon,
  label,
  external,
}: {
  href: string;
  icon: typeof Home;
  label: string;
  external?: boolean;
}) {
  return (
    <a
      href={href}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      className="flex flex-col items-center gap-1 rounded-xl px-2 py-2.5 text-[10px] font-extrabold text-smoke transition-colors hover:bg-sand hover:text-pine active:bg-sand"
    >
      <Icon className="h-5 w-5" aria-hidden />
      {label}
    </a>
  );
}

function DockButton({
  onClick,
  icon: Icon,
  label,
  accent,
}: {
  onClick: () => void;
  icon: typeof Home;
  label: string;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 rounded-xl px-2 py-2.5 text-[10px] font-extrabold transition-colors ${
        accent ? "bg-pine text-cream shadow-md" : "text-smoke hover:bg-sand hover:text-pine"
      }`}
    >
      <Icon className="h-5 w-5" aria-hidden />
      {label}
    </button>
  );
}
