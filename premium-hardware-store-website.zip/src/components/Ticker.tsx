const ITEMS = [
  "Steel Bartan",
  "Kitchenware",
  "Hardware & Fittings",
  "Hand Tools",
  "Home Essentials",
  "Serving & Storage",
  "Repair Essentials",
  "Cookware",
];

export default function Ticker() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="relative overflow-hidden border-y border-pine-deep bg-pine py-4" aria-hidden>
      <div className="animate-marquee flex w-max items-center">
        {row.map((item, i) => (
          <span key={i} className="flex items-center">
            <span className="px-6 font-display text-sm font-medium tracking-[0.14em] text-cream/90 uppercase md:text-base">
              {item}
            </span>
            <span className="inline-block h-1.5 w-1.5 rotate-45 bg-brass-soft" />
          </span>
        ))}
      </div>
    </div>
  );
}
