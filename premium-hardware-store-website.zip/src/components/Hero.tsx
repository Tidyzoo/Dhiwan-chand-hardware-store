import { ArrowRight, MapPin, MessageCircle, UtensilsCrossed, Wrench, House, Hammer } from "lucide-react";
import { STORE } from "../config";
import { useEnquiry } from "./Enquiry";
import Reveal from "./Reveal";

const CHIPS = [
  { icon: UtensilsCrossed, label: "Bartan & Kitchenware" },
  { icon: Wrench, label: "Hardware & Fittings" },
  { icon: Hammer, label: "Tools & Accessories" },
  { icon: House, label: "Everyday Home Essentials" },
];

export default function Hero() {
  const enquire = useEnquiry();

  return (
    <section id="home" className="relative overflow-hidden pt-28 pb-16 md:pt-40 md:pb-24">
      {/* backdrop wash + dot grid */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(900px 480px at 85% -10%, rgba(166,124,60,0.14), transparent 60%), radial-gradient(760px 520px at -10% 110%, rgba(20,53,42,0.10), transparent 60%)",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage: "radial-gradient(rgba(27,30,27,0.10) 1px, transparent 1px)",
          backgroundSize: "26px 26px",
          maskImage: "radial-gradient(ellipse 90% 70% at 50% 0%, black, transparent 75%)",
          WebkitMaskImage: "radial-gradient(ellipse 90% 70% at 50% 0%, black, transparent 75%)",
        }}
      />
      {/* oversized ghost word */}
      <span
        aria-hidden
        className="pointer-events-none absolute -top-4 left-1/2 -translate-x-1/2 font-display text-[18vw] font-bold tracking-tight whitespace-nowrap text-transparent select-none md:text-[13rem]"
        style={{ WebkitTextStroke: "1px rgba(20,53,42,0.10)" }}
      >
        NISSING
      </span>

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
        {/* Copy */}
        <div>
          <Reveal>
            <p className="inline-flex items-center gap-2 rounded-full border border-line bg-cream px-4 py-2 text-[11px] font-bold tracking-wide text-smoke shadow-sm md:text-xs">
              <MapPin className="h-3.5 w-3.5 text-brass" aria-hidden />
              {STORE.addressShort}
            </p>
          </Reveal>

          <Reveal delay={90}>
            <h1 className="text-balance mt-6 font-display text-[2.65rem] leading-[1.04] font-semibold tracking-tight text-ink sm:text-6xl lg:text-[4.2rem]">
              Quality Hardware. Everyday Essentials.{" "}
              <em className="font-medium text-pine italic">One Trusted Store.</em>
            </h1>
          </Reveal>

          <Reveal delay={180}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-smoke md:text-lg">
              Explore hardware, household utensils and everyday essentials at{" "}
              <span className="font-semibold text-ink">{STORE.name}</span>, Nissing — everything
              for your home, tools &amp; daily needs, under one roof.
            </p>
          </Reveal>

          <Reveal delay={260}>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <a
                href="#products"
                className="group inline-flex items-center gap-2.5 rounded-full bg-pine px-7 py-4 text-sm font-bold text-cream transition-all duration-300 hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-[0_16px_32px_-12px_rgba(20,53,42,0.5)]"
              >
                Explore Products
                <ArrowRight
                  className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                  aria-hidden
                />
              </a>
              <a
                href="#visit"
                className="group inline-flex items-center gap-2.5 rounded-full border border-ink/20 bg-cream px-7 py-4 text-sm font-bold text-ink transition-all duration-300 hover:-translate-y-0.5 hover:border-pine hover:text-pine hover:shadow-lg"
              >
                <MapPin className="h-4 w-4 text-brass transition-colors group-hover:text-pine" aria-hidden />
                Visit Our Store
              </a>
            </div>
          </Reveal>

          <Reveal delay={340}>
            <ul className="mt-10 flex flex-wrap gap-2.5" aria-label="Store range">
              {CHIPS.map(({ icon: Icon, label }) => (
                <li
                  key={label}
                  className="inline-flex items-center gap-2 rounded-full border border-line bg-white/70 px-4 py-2.5 text-xs font-bold text-smoke transition-colors hover:border-brass/40 hover:text-ink"
                >
                  <Icon className="h-3.5 w-3.5 text-brass" aria-hidden />
                  {label}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>

        {/* Imagery */}
        <Reveal delay={200} className="relative">
          <div className="relative mx-auto max-w-[520px]">
            <div
              aria-hidden
              className="absolute -inset-3 -rotate-2 rounded-[2.2rem] border border-brass/40"
            />
            <div className="relative overflow-hidden rounded-[2rem] shadow-[0_40px_80px_-30px_rgba(14,38,29,0.55)]">
              <img
                src="/images/hero.jpg"
                alt="Inside Diwan Chand Bartan and Hardware Store — stainless steel bartan, cookware and tools on display"
                className="aspect-[4/4.4] w-full object-cover sm:aspect-[4/4]"
                loading="eager"
                fetchPriority="high"
              />
              <div
                aria-hidden
                className="absolute inset-0 bg-gradient-to-t from-pine-deep/45 via-transparent to-transparent"
              />
              {/* bottom label */}
              <div className="absolute inset-x-5 bottom-5 flex items-center justify-between gap-3 rounded-2xl border border-cream/20 bg-pine-deep/70 px-5 py-4 backdrop-blur-md">
                <div>
                  <p className="text-[10px] font-bold tracking-[0.2em] text-brass-soft uppercase">
                    Everything under one roof
                  </p>
                  <p className="mt-0.5 font-display text-sm font-medium text-cream">
                    Bartan · Hardware · Tools · Home
                  </p>
                </div>
                <MapPin className="h-5 w-5 shrink-0 text-brass-soft" aria-hidden />
              </div>
            </div>

            {/* floating enquiry chip */}
            <button
              onClick={() => enquire()}
              className="animate-float group absolute -left-4 top-8 flex items-center gap-3 rounded-2xl border border-line bg-cream px-4 py-3 text-left shadow-[0_20px_44px_-16px_rgba(27,30,27,0.35)] transition-transform hover:scale-[1.03] sm:-left-10"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-pine text-cream">
                <MessageCircle className="h-4 w-4" aria-hidden />
              </span>
              <span>
                <span className="block text-[13px] font-extrabold text-ink">Ask for a price</span>
                <span className="block text-[11px] font-semibold text-smoke">
                  Quick product enquiry
                </span>
              </span>
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
