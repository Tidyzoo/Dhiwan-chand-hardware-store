import { useEffect, useState } from "react";
import { MapPin, Menu, X, MessageCircle } from "lucide-react";
import { STORE } from "../config";
import { useEnquiry } from "./Enquiry";

const LINKS = [
  { label: "Categories", href: "#categories" },
  { label: "Products", href: "#products" },
  { label: "Why Us", href: "#why-us" },
  { label: "Visit", href: "#visit" },
  { label: "Gallery", href: "#gallery" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const enquire = useEnquiry();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.documentElement.style.overflow = open ? "hidden" : "";
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled
            ? "border-b border-line bg-cream/90 shadow-[0_4px_24px_-12px_rgba(27,30,27,0.15)] backdrop-blur-xl"
            : "border-b border-transparent bg-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 md:h-20 md:px-8">
          {/* Brand */}
          <a href="#home" className="group flex items-center gap-3" aria-label="Diwan Chand Bartan and Hardware Store — home">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-pine font-display text-sm font-semibold text-brass-soft shadow-md transition-transform duration-300 group-hover:-rotate-6 md:h-11 md:w-11">
              DC
            </span>
            <span className="leading-tight">
              <span className="block font-display text-[15px] font-semibold tracking-wide text-ink md:text-base">
                {STORE.brandLine1}
              </span>
              <span className="block text-[10px] font-bold tracking-[0.22em] text-smoke uppercase md:text-[11px]">
                Bartan &amp; Hardware
              </span>
            </span>
          </a>

          {/* Desktop links */}
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="relative text-[13px] font-bold text-smoke transition-colors after:absolute after:-bottom-1.5 after:left-0 after:h-[2px] after:w-0 after:rounded-full after:bg-brass after:transition-all after:duration-300 hover:text-ink hover:after:w-full"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-1.5 rounded-full border border-line bg-white/70 px-3.5 py-2 text-[11px] font-bold text-smoke xl:inline-flex">
              <MapPin className="h-3.5 w-3.5 text-brass" aria-hidden />
              Nissing, Haryana
            </span>
            <button
              onClick={() => enquire()}
              className="hidden items-center gap-2 rounded-full bg-pine px-5 py-2.5 text-[13px] font-bold text-cream transition-all hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-lg sm:inline-flex"
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              Enquire
            </button>
            <button
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              className="rounded-full border border-line bg-white/70 p-2.5 text-ink lg:hidden"
            >
              <Menu className="h-5 w-5" aria-hidden />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu overlay */}
      <div
        className={`fixed inset-0 z-[70] flex flex-col bg-pine-deep text-cream transition-all duration-500 lg:hidden ${
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
        }`}
        role="dialog"
        aria-modal="true"
        aria-label="Menu"
      >
        <div className="flex h-16 items-center justify-between px-5">
          <span className="font-display text-lg font-semibold">
            {STORE.brandLine1}
            <span className="block text-[10px] font-sans font-bold tracking-[0.22em] text-brass-soft uppercase">
              Bartan &amp; Hardware
            </span>
          </span>
          <button
            onClick={() => setOpen(false)}
            aria-label="Close menu"
            className="rounded-full border border-cream/20 p-2.5 transition hover:bg-cream/10"
          >
            <X className="h-5 w-5" aria-hidden />
          </button>
        </div>
        <nav className="flex flex-1 flex-col justify-center gap-1 px-8" aria-label="Mobile">
          {[{ label: "Home", href: "#home" }, ...LINKS].map((l, i) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className={`border-b border-cream/10 py-4 font-display text-2xl font-medium transition-all duration-500 hover:pl-2 hover:text-brass-soft ${
                open ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
              }`}
              style={{ transitionDelay: `${80 + i * 50}ms` }}
            >
              {l.label}
            </a>
          ))}
        </nav>
        <div className="space-y-3 px-8 pb-24">
          <button
            onClick={() => {
              setOpen(false);
              enquire();
            }}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-brass-soft px-6 py-4 text-sm font-bold text-pine-deep"
          >
            <MessageCircle className="h-4 w-4" aria-hidden />
            Ask About a Product
          </button>
          <p className="flex items-center justify-center gap-1.5 text-xs text-cream/60">
            <MapPin className="h-3.5 w-3.5" aria-hidden /> {STORE.addressShort}
          </p>
        </div>
      </div>
    </>
  );
}
