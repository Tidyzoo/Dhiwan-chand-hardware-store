import { MapPin, Navigation, Clock, Store } from "lucide-react";
import { STORE, DIRECTIONS_URL, MAPS_EMBED_URL } from "../config";
import Reveal from "./Reveal";

export default function StoreVisit() {
  return (
    <section id="visit" className="scroll-mt-24 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          {/* Imagery */}
          <Reveal className="relative order-2 lg:order-1">
            <div className="relative">
              <div className="overflow-hidden rounded-[2rem] shadow-[var(--shadow-deep)]">
                <img
                  src="/images/store-interior.jpg"
                  alt="Interior of the store — shelves stocked with steel bartan, containers and hardware items"
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover transition-transform duration-700 hover:scale-[1.03]"
                />
              </div>
              <div className="absolute -right-3 -bottom-8 hidden w-44 overflow-hidden rounded-2xl border-4 border-ivory shadow-[var(--shadow-lift)] sm:block md:w-56">
                <img
                  src="/images/store-exterior.jpg"
                  alt="Store front in the evening with steel bartan displayed at the entrance"
                  loading="lazy"
                  className="aspect-[4/5] w-full object-cover"
                />
              </div>
              {/* Local trust chip */}
              <div className="absolute top-4 left-4 flex items-center gap-2.5 rounded-full border border-cream/30 bg-pine-deep/70 py-2 pr-5 pl-2 backdrop-blur-md">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brass-soft text-pine-deep">
                  <Store className="h-4 w-4" aria-hidden />
                </span>
                <span className="text-[11px] leading-tight font-bold text-cream">
                  Serving Nissing
                  <span className="block font-semibold text-cream/70">&amp; nearby areas</span>
                </span>
              </div>
            </div>
          </Reveal>

          {/* Copy + location card */}
          <div className="order-1 lg:order-2">
            <Reveal>
              <p className="flex items-center gap-3 text-[11px] font-bold tracking-[0.24em] text-brass uppercase">
                <span className="h-px w-8 bg-brass" aria-hidden />
                The Store Experience
              </p>
              <h2 className="text-balance mt-4 font-display text-4xl font-semibold tracking-tight text-ink md:text-5xl">
                Visit Us in <em className="text-pine italic">Nissing</em>
              </h2>
              <p className="mt-5 max-w-lg text-base leading-relaxed text-smoke">
                Walk the aisles, compare products in person and pick exactly what your home
                needs — steel bartan and kitchenware, hardware fittings, tools and everyday
                essentials, all under one roof.
              </p>
            </Reveal>

            <Reveal delay={140}>
              <address className="mt-8 rounded-3xl border border-line bg-cream p-7 shadow-[var(--shadow-card)] not-italic">
                <p className="text-[11px] font-extrabold tracking-[0.2em] text-brass uppercase">
                  Store Address
                </p>
                <h3 className="mt-2 font-display text-xl font-semibold text-ink">
                  {STORE.name}
                </h3>
                <p className="mt-2 flex items-start gap-2 text-sm leading-relaxed text-smoke">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brass" aria-hidden />
                  {STORE.address}
                </p>
                <p className="mt-2 flex items-start gap-2 text-sm leading-relaxed text-smoke">
                  <Clock className="mt-0.5 h-4 w-4 shrink-0 text-brass" aria-hidden />
                  <span>
                    Opening hours:{" "}
                    <span className="font-mono font-semibold text-ink">{STORE.hoursDisplay}</span>
                  </span>
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  <a
                    href={DIRECTIONS_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-2 rounded-full bg-pine px-6 py-3.5 text-sm font-bold text-cream transition-all hover:-translate-y-0.5 hover:bg-pine-soft hover:shadow-lg"
                  >
                    <Navigation className="h-4 w-4" aria-hidden />
                    Get Directions
                  </a>
                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 rounded-full border border-ink/15 px-6 py-3.5 text-sm font-bold text-ink transition-all hover:border-pine hover:text-pine"
                  >
                    Contact the Store
                  </a>
                </div>
              </address>
            </Reveal>
          </div>
        </div>

        {/* Map */}
        <Reveal delay={120}>
          <div className="mt-16 overflow-hidden rounded-[2rem] border border-line shadow-[var(--shadow-card)] md:mt-24">
            <iframe
              title="Map — Diwan Chand Bartan & Hardware Store, Nissing, Haryana"
              src={MAPS_EMBED_URL}
              className="h-[320px] w-full md:h-[420px]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
